﻿using System.Drawing.Imaging;

namespace FILECOSHOME
{
    public partial class Form4 : Form
    {
        public Form4()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            using (OpenFileDialog openFileDialog1 = new OpenFileDialog())
            {
                openFileDialog1.Filter = "JPG Images|*.jpg;*.jpeg|All Files|*.*";
                openFileDialog1.Title = "Select JPG Images";
                openFileDialog1.Multiselect = false;

                if (openFileDialog1.ShowDialog() == DialogResult.OK)
                {
                    string selectedFileName = openFileDialog1.FileName;
                    long fileSize = new FileInfo(selectedFileName).Length;

                    if (fileSize <= 200 * 1024 * 1024) // Check if file size is less than or equal to 200MB
                    {
                        string pngFilePath = Path.Combine(Path.GetDirectoryName(selectedFileName), Path.GetFileNameWithoutExtension(selectedFileName) + ".png");
                        txtdirectory.Text = pngFilePath;
                        ConvertToPng(selectedFileName, pngFilePath);
                    }
                    else
                    {
                        MessageBox.Show("File size exceeds the limit of 200MB. Please choose a smaller file.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                }
            }
        }

        private void ConvertToPng(string jpgFilePath, string pngFilePath)
        {
            try
            {
                using (Image image = Image.FromFile(jpgFilePath))
                {
                    pngFilePath = Path.ChangeExtension(pngFilePath, ".png");
                    Bitmap pngImage = new Bitmap(image.Width, image.Height);

                    using (Graphics g = Graphics.FromImage(pngImage))
                    {
                        g.DrawImage(image, new Rectangle(0, 0, pngImage.Width, pngImage.Height));
                    }

                    pngImage.Save(pngFilePath, ImageFormat.Png);
                }

                MessageBox.Show("The file has been successfully converted!");
            }
            catch (Exception ex)
            {
                MessageBox.Show($"An error occurred: {ex.Message}", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            Home home = new Home();
            home.Show();
            this.Hide();
        }
    }
}