﻿using iText.Kernel.Pdf;

namespace iText.Layout
{
    internal class Converter
    {
        internal class XmlToPdf
        {
            private Document document;
            private PdfWriter writer;

            public XmlToPdf(Document document, PdfWriter writer)
            {
                this.document = document;
                this.writer = writer;
            }

            internal void Convert()
            {
                throw new NotImplementedException();
            }
        }
    }
}