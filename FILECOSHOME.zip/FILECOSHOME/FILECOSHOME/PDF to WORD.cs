﻿using Aspose.Pdf;

namespace FILECOSHOME
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            OpenFileDialog openFileDialog1 = new OpenFileDialog();

            openFileDialog1.Filter = "PDF Files|*.pdf";
            openFileDialog1.Title = "Select a PDF File";

            if (openFileDialog1.ShowDialog() == DialogResult.OK)
            {
                string selectedFileName = openFileDialog1.FileName;

                long fileSizeInBytes = new System.IO.FileInfo(selectedFileName).Length;
                long maxSizeInBytes = 200 * 1024 * 1024;

                if (fileSizeInBytes > maxSizeInBytes)
                {
                    MessageBox.Show("Selected file exceeds the 200 MB limit. Please choose a smaller file.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    return;
                }

                txtdirectory.Text = selectedFileName;
                ConvertToDocx(selectedFileName);
            }
        }

        private void ConvertToDocx(string pdfFilePath)
        {
            Document pdfDocument = new Document(pdfFilePath);
            string docxFilePath = pdfFilePath.Replace(".pdf", ".docx");

            pdfDocument.Save(docxFilePath, SaveFormat.DocX);

            MessageBox.Show("The file has been successfully converted!");
        }

        private void button2_Click(object sender, EventArgs e)
        {
            Home home = new Home();
            home.Show();
            this.Hide();
        }
    }
}