﻿
namespace FILECOSHOME
{
    internal class DocX : IDisposable
    {
        public void Dispose()
        {
            throw new NotImplementedException();
        }

        internal void InsertParagraph(string text)
        {
            throw new NotImplementedException();
        }

        internal void SaveAs(string docxFilePath)
        {
            throw new NotImplementedException();
        }
    }
}