﻿using PdfSharp.Drawing;
using PdfSharp.Pdf;

namespace FILECOSHOME
{
    public partial class Form3 : Form
    {
        public Form3()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            OpenFileDialog openFileDialog1 = new OpenFileDialog();

            openFileDialog1.Filter = "JPEG Files|*.jpg;*.jpeg";
            openFileDialog1.Multiselect = true;
            openFileDialog1.Title = "Select JPEG Files";

            if (openFileDialog1.ShowDialog() == DialogResult.OK)
            {
                string[] selectedFileNames = openFileDialog1.FileNames;

                long totalFileSizeInBytes = selectedFileNames.Sum(filePath => new FileInfo(filePath).Length);
                long maxSizeInBytes = 200 * 1024 * 1024;

                if (totalFileSizeInBytes > maxSizeInBytes)
                {
                    MessageBox.Show("Selected files exceed the 200 MB limit. Please choose smaller files.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    return;
                }
                txtdirectory.Text = string.Join(", ", selectedFileNames);
                ConvertToPdf(selectedFileNames);
            }
        }

        private void ConvertToPdf(string[] imagePaths)
        {
            string originalFilePath = imagePaths[0];
            string pdfFilePath = Path.ChangeExtension(originalFilePath, "pdf");

            using (PdfDocument pdf = new PdfDocument())
            {
                foreach (string imagePath in imagePaths)
                {
                    PdfPage page = pdf.AddPage();
                    XGraphics gfx = XGraphics.FromPdfPage(page);
                    XImage image = XImage.FromFile(imagePath);

                    gfx.DrawImage(image, 0, 0);
                }

                pdf.Save(pdfFilePath);
            }

            MessageBox.Show("The file has been successfully converted!");
        }

        private void button2_Click(object sender, EventArgs e)
        {
            Home home = new Home();
            home.Show();
            this.Hide();
        }
    }
}