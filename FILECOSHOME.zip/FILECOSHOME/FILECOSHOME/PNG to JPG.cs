﻿using System.Drawing.Imaging;

namespace FILECOSHOME
{
    public partial class Form5 : Form
    {
        public Form5()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            using (OpenFileDialog openFileDialog = new OpenFileDialog())
            {
                openFileDialog.Filter = "PNG files (*.png)|*.png|All files (*.*)|*.*";

                if (openFileDialog.ShowDialog() == DialogResult.OK)
                {
                    string pngFilePath = openFileDialog.FileName;
                    txtdirectory.Text = pngFilePath;

                    long fileSize = new FileInfo(pngFilePath).Length;

                    if (fileSize <= 200 * 1024 * 1024)
                    {
                        string jpgFilePath = Path.ChangeExtension(pngFilePath, "jpg");

                        ConvertPngToJpg(pngFilePath, jpgFilePath);

                        MessageBox.Show("The file has been successfully converted!", "Completed!", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    }
                    else
                    {
                        MessageBox.Show("Selected files exceed the 200 MB limit. Please choose smaller files.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                }
            }
        }

        private void ConvertPngToJpg(string pngFilePath, string jpgFilePath)
        {
            using (Bitmap bitmap = new Bitmap(pngFilePath))
            {
                bitmap.Save(jpgFilePath, ImageFormat.Jpeg);
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            Home home = new Home();
            home.Show();
            this.Hide();
        }
    }
}