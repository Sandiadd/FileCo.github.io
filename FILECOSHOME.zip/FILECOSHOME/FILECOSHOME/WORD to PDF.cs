﻿using Microsoft.Office.Interop.Word;
using Application = Microsoft.Office.Interop.Word.Application;

namespace FILECOSHOME
{
    public partial class Form2 : Form
    {
        public Form2()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            OpenFileDialog openFileDialog1 = new OpenFileDialog();

            openFileDialog1.Filter = "Word Documents|*.docx";
            openFileDialog1.Title = "Select a Word Document";

            if (openFileDialog1.ShowDialog() == DialogResult.OK)
            {
                string selectedFileName = openFileDialog1.FileName;

                long fileSizeInBytes = new System.IO.FileInfo(selectedFileName).Length;
                long maxSizeInBytes = 200 * 1024 * 1024;

                if (fileSizeInBytes > maxSizeInBytes)
                {
                    MessageBox.Show("Selected file exceeds the 200 MB limit. Please choose a smaller file.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    return;
                }

                txtdirectory.Text = selectedFileName;
                ConvertToPDF(selectedFileName);
            }
        }

        private void ConvertToPDF(string docxFilePath)
        {
            var wordApp = new Application();
            var doc = wordApp.Documents.Open(docxFilePath);

            string pdfFilePath = docxFilePath.Replace(".docx", ".pdf");

            doc.ExportAsFixedFormat(pdfFilePath, WdExportFormat.wdExportFormatPDF);

            doc.Close();
            wordApp.Quit();

            MessageBox.Show("The file has been successfully converted!");
        }

        private void button2_Click(object sender, EventArgs e)
        {
            Home home = new Home();
            home.Show();
            this.Hide();
        }
    }
}
